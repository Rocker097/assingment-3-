module.exports = app => {
  const specialisations = require("../controllers/specialisation.controller.js");

  var router = require("express").Router();

  // Create a new Specialisation
  router.post("/", specialisations.create);

  // Retrieve all Specialisations
  router.get("/", specialisations.findAll);

  // Retrieve a single Specialisation with id
  router.get("/:id", specialisations.findOne);

  // Update a Specialisation with id
  router.put("/:id", specialisations.update);

  // Delete a Specialisation with id
  router.delete("/:id", specialisations.delete);

  // Create a new Specialisation
  router.delete("/", specialisations.deleteAll);

  app.use("/api/specialisations", router);
};
